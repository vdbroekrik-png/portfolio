let naam = prompt("Wat is jouw naam?");

alert('welkom bij het spel, ' + naam + 'je ziet 2 deuren A en B. Welke deur kies je?');

let deur = prompt("Kies A of B");

if (deur === 'A' || deur === 'a') {
    alert('Je hebt deur A gekozen. Er zit een leeuw achter de deur! Je bent opgegeten. Einde spel.');
}

else if (deur === 'B' || deur === 'b') {
    alert('Je hebt deur B gekozen. Er zit een schatkist achter de deur! Je bent rijk geworden. Gefeliciteerd, ' + naam + '!');
}

let monster = prompt("Je komt een monster tegen! Wil je vechten of wegrennen? (typen: vechten/wegrennen)");

if (monster === 'vechten') {
    alert('Je hebt ervoor gekozen om te vechten. Je hebt het monster verslagen! Goed gedaan, ' + naam + '!');
}
else if (monster === 'wegrennen') {
    alert('Je hebt ervoor gekozen om weg te rennen. Het monster heeft je ingehaald. Einde spel.');
}
else {
    alert('Ongeldige keuze. Het spel is afgelopen.');
}

let leeftijd = prompt('vul je leeftijd in');

if (leeftijd >= 18) { 
    alert('Je bent oud genoeg om dit spel te spelen, veel succes!');
} else if (leeftijd < 18) {
    alert('Helaas, je bent niet oud genoeg om dit spel te spelen.');
}